﻿Public Class POS___Sales_DataBase
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Visible = False
        Main_Administration_screen.Visible = True

    End Sub
End Class