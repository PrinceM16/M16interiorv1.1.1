﻿Public Class Clients_Database
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'The Previous action for the button of Previous
        ClientsdbBindingSource.MovePrevious()


    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Me.Visible = False
        Main_Administration_screen.Visible = True
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Me.Close()
        Application.Exit()
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Me.Visible = False
        AboutBox1.Visible = True

    End Sub

    Private Sub Clients_Database_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'M16ClientsDataSet.Clientsdb' table. You can move, or remove it, as needed.

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        'The button is to add new clients by adding the data entered
        ClientsdbBindingSource.AddNew()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        'The button is for moving forward from the previous clients captured.
        ClientsdbBindingSource.MoveNext()

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        'This button is to save the data entered by the end user capturing the data from the clients.
        On Error GoTo SaveErr
        'Connecting the strings of the directory of the saving files 

        ClientsdbTableAdapter.Update(M16ClientsDataSet.Clientsdb)

        MessageBox.Show("Ok  I will do so")


SaveErr:
        Exit Sub


    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        'This button is to perform an action of deleting everything and clearing that rows and cololums 
        ClientsdbBindingSource.RemoveCurrent()

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click

        'This button is to perform an action of editing everything and adding new information that rows and cololums
        ClientsdbBindingSource.EndEdit()

    End Sub
End Class