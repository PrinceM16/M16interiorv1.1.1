﻿Public Interface Interface1

End Interface
