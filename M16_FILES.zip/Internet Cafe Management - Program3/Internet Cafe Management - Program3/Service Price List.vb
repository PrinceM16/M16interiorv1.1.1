﻿Public Class Service_Price_List
    'TODO: THIS WHOLE FORM
    'This is declared fr the comboboxes selection
    Dim Internet As String
    Dim CopiesBW As String
    Dim CopiesColour As String
    Dim PrintingBw As String
    Dim PrintingColourPaper As String
    Dim A3BWCopies As String
    Dim businesscards As String
    Dim A3Printsout As String
    Dim ColourPrintsOutA3 As String
    Dim TypedDocuments As String
    Dim EditedPages As String
    Dim Assignmentpages As String
    Dim theInvoices As String
    Dim WiFiVouchers As String
    Dim LogoDesigns As String
    Dim CompanyLetterHeads As String
    Dim Flyers As String
    Dim h3DhousePlansVisualizations As String
    Dim InvoiceDesigns As String
    Dim CompanyRegistrations As String
    Dim d25006DFlyersGlossyPapers As String
    Dim d50006DFlyersGlossyPapers As String
    Dim A4LaminateFlyers As String
    Dim A3BWLaminated As String
    Dim A4FilePockets As String
    Dim A4BrownEnvelopes As String
    Dim GBUSBDrives As String
    Dim NumberofBigValuePacks As String
    Dim OnlineRegistrations As String


    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Visible = False
        Main_Administration_screen.Visible = True
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Visible = False
        Form1.Visible = True
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'For the Internet Combobox SELECTION
        If ComboBox1.SelectedText = Internet Then
            Price_List.Items.Add("The internet charges as follows:")
            Price_List.Items.Add("The Internet is: R6.00 for 15 Minutes.")
            Price_List.Items.Add("The Internet is: R12.00 for 30 Minutes.")
            Price_List.Items.Add("The Internet is: R18.00 for 45 Minutes.")
            Price_List.Items.Add("The Internet is: R24.00 for 1 Hour.")
            Price_List.Items.Add("The Internet is: R48.00 for 2 Hourss.")

        Else
            'For the Internet Combobox SELECTION
            If ComboBox1.SelectedText = CopiesBW Then
                Price_List.Items.Add("The Black / White Copies charges as follows:")
                Price_List.Items.Add("Per copy is: R2.00 per page one side.")
                Price_List.Items.Add("If you make copies both sides R3.00 per page two sided sides.")
                Price_List.Items.Add("If it happens that you doing more than 25 Copies there will be an discount")

            Else


                'For the Internet Combobox SELECTION
                If ComboBox1.SelectedText = CopiesColour Then
                    Price_List.Items.Add("The Colour Copies charges as follows:")
                    Price_List.Items.Add("Per Colour Copy is : R4.00")

                Else

                    'For the Internet Combobox SELECTION
                    If ComboBox1.SelectedText = PrintingBw Then
                        Price_List.Items.Add("The Printing Black / White Papers charges as follows:")
                        Price_List.Items.Add("The Printing B/W is: R3.00 Per paper.")

                    Else

                        'For the Internet Combobox SELECTION
                        If ComboBox1.SelectedText = PrintingColourPaper Then
                            Price_List.Items.Add("The Printing Colour papers charges as follows:")
                            Price_List.Items.Add("The Colour Printing is: R6.00 per paper.")

                        Else

                            'For the Internet Combobox SELECTION
                            If ComboBox1.SelectedText = A3BWCopies Then
                                Price_List.Items.Add("The A3 B/W Copies charges as follows:")
                                Price_List.Items.Add("The A3 B/W Copies is: R8.00 per paper.")


                                'For the Internet Combobox SELECTION
                                If ComboBox1.SelectedText = businesscards Then
                                    Price_List.Items.Add("The Business Card charges as follows:")
                                    Price_List.Items.Add("The Business Cards to create per Bundle its: R15,00.")

                                Else

                                    'For the Internet Combobox SELECTION
                                    If ComboBox1.SelectedText = A3Printsout Then
                                        Price_List.Items.Add("The Black / White A3 Printing charges as follows:")
                                        Price_List.Items.Add("The Black / White A3 Printing is: R8,00.")

                                    Else

                                        'For the Internet Combobox SELECTION
                                        If ComboBox1.SelectedText = ColourPrintsOutA3 Then
                                            Price_List.Items.Add("The Colour Printing A3 charges as follows:")
                                            Price_List.Items.Add("The Colour Printing for A3 it is: R12,00.")

                                        Else

                                            'For the Internet Combobox SELECTION
                                            If ComboBox1.SelectedText = TypedDocuments Then
                                                Price_List.Items.Add("The Typed Documents charges as follows:")
                                                Price_List.Items.Add("The Typing Document is: R20,00 per page.")

                                            Else


                                                'For the Internet Combobox SELECTION
                                                If ComboBox1.SelectedText = EditedPages Then
                                                    Price_List.Items.Add("The Edition of documents charges as follows:")
                                                    Price_List.Items.Add("The Edited Pages each it will be: R10,00 per page.")

                                                Else

                                                    'For the Internet Combobox SELECTION
                                                    If ComboBox1.SelectedText = Assignmentpages Then
                                                        Price_List.Items.Add("The Assessments charges as follows:")
                                                        Price_List.Items.Add("The Asssignments to be done is: R15,00 per page.")

                                                    Else


                                                        'For the Internet Combobox SELECTION
                                                        If ComboBox1.SelectedText = theInvoices Then
                                                            Price_List.Items.Add("The Invoices charges as follows:")
                                                            Price_List.Items.Add("The Invoices to be done is: R100,00.")

                                                        Else

                                                            'For the Internet Combobox SELECTION
                                                            If ComboBox1.SelectedText = WiFiVouchers Then
                                                                Price_List.Items.Add("The WiFi Vouchers charges as follows:")
                                                                Price_List.Items.Add("The WiFi Voucher is Valid at: R20,00.")

                                                            Else

                                                                'For the Internet Combobox SELECTION
                                                                If ComboBox1.SelectedText = LogoDesigns Then
                                                                    Price_List.Items.Add("The Logo Designs charges as follows:")
                                                                    Price_List.Items.Add("The Logo Designs is: R375,00.")

                                                                Else

                                                                    'For the Internet Combobox SELECTION
                                                                    If ComboBox1.SelectedText = CompanyLetterHeads Then
                                                                        Price_List.Items.Add("The Company Letterheads charges as follows:")
                                                                        Price_List.Items.Add("The Company LetterHeads to do is: R100,00.")

                                                                    Else

                                                                        'For the Internet Combobox SELECTION
                                                                        If ComboBox1.SelectedText = Flyers Then
                                                                            Price_List.Items.Add("The Flyer/Poster charges as follows:")
                                                                            Price_List.Items.Add("The Flyer or Poster to be designed is: R80,00.")

                                                                        Else

                                                                            'For the Internet Combobox SELECTION
                                                                            If ComboBox1.SelectedText = h3DhousePlansVisualizations Then
                                                                                Price_List.Items.Add("The 3D House Plans Visualization charges as follows:")
                                                                                Price_List.Items.Add("The 3D House Plan Visualization is: R (POR).")

                                                                            Else

                                                                                'For the Internet Combobox SELECTION
                                                                                If ComboBox1.SelectedText = InvoiceDesigns Then
                                                                                    Price_List.Items.Add("The Invoice Design charges as follows:")
                                                                                    Price_List.Items.Add("The Invoice Designs is: R350,00.")

                                                                                Else

                                                                                    'For the Internet Combobox SELECTION
                                                                                    If ComboBox1.SelectedText = CompanyRegistrations Then
                                                                                        Price_List.Items.Add("The Company Registarations charges as follows:")
                                                                                        Price_List.Items.Add("The company registration is R450,00 per company.")

                                                                                    Else

                                                                                        'For the Internet Combobox SELECTION
                                                                                        If ComboBox1.SelectedText = d25006DFlyersGlossyPapers Then
                                                                                            Price_List.Items.Add("The 2500D Gloosy Flyers papers charges as follows:")
                                                                                            Price_List.Items.Add("The 2500D Glossy Flyers is: R2,00 per paper")

                                                                                        Else

                                                                                            'For the Internet Combobox SELECTION
                                                                                            If ComboBox1.SelectedText = d50006DFlyersGlossyPapers Then
                                                                                                Price_List.Items.Add("The 5000D Flyers Glossy Paper charges as follows:")
                                                                                                Price_List.Items.Add("The 5000D Glossy Flyers is: R1,80 Per paper.")

                                                                                            Else

                                                                                                'For the Internet Combobox SELECTION
                                                                                                If ComboBox1.SelectedText = A4LaminateFlyers Then
                                                                                                    Price_List.Items.Add("The Lamination for A4 B/W paper charges as follows:")
                                                                                                    Price_List.Items.Add("The Lamination is: R15,00 per page")

                                                                                                Else

                                                                                                    'For the Internet Combobox SELECTION
                                                                                                    If ComboBox1.SelectedText = A3BWLaminated Then
                                                                                                        Price_List.Items.Add("The A3 B/W Lamination charges as follows:")
                                                                                                        Price_List.Items.Add("The A3 Lamination is: R15.00 per page.")

                                                                                                    Else

                                                                                                        'For the Internet Combobox SELECTION
                                                                                                        If ComboBox1.SelectedText = A4FilePockets Then
                                                                                                            Price_List.Items.Add("The A4 File Pockets charges as follows:")
                                                                                                            Price_List.Items.Add("The A4 File Pocket is: R4.00 each.")

                                                                                                        Else

                                                                                                            'For the Internet Combobox SELECTION
                                                                                                            If ComboBox1.SelectedText = A4BrownEnvelopes Then
                                                                                                                Price_List.Items.Add("The A4 Brown Envelope charges as follows:")
                                                                                                                Price_List.Items.Add("The A4 Brown Envelope is R6,00 each.")

                                                                                                            Else

                                                                                                                'For the Internet Combobox SELECTION
                                                                                                                If ComboBox1.SelectedText = GBUSBDrives Then
                                                                                                                    Price_List.Items.Add("The 8GB USB charges as follows:")
                                                                                                                    Price_List.Items.Add("The USB Removal is R80,00 each.")

                                                                                                                Else

                                                                                                                    'For the Internet Combobox SELECTION
                                                                                                                    If ComboBox1.SelectedText = NumberofBigValuePacks Then
                                                                                                                        Price_List.Items.Add("The price for Big Value Packs charges as follows:")
                                                                                                                        Price_List.Items.Add("The Big Value Pack is R40.00")

                                                                                                                    Else


                                                                                                                        'For the Internet Combobox SELECTION
                                                                                                                        If ComboBox1.SelectedText = OnlineRegistrations Then
                                                                                                                            Price_List.Items.Add("The Online Registrations charges as follows:")
                                                                                                                            Price_List.Items.Add("The online registrations are R20,00 if succeed but if failed R10,00.")

                                                                                                                        End If

                                                                                                                    End If
                                                                                                                End If

                                                                                                            End If
                                                                                                        End If
                                                                                                    End If
                                                                                                End If
                                                                                            End If
                                                                                        End If
                                                                                    End If
                                                                                End If
                                                                            End If
                                                                        End If
                                                                    End If
                                                                End If
                                                            End If
                                                        End If
                                                    End If
                                                End If
                                            End If
                                        End If
                                    End If
                                End If

                            End If
                        End If
                    End If
                End If
            End If
        End If

    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        If RadioButton2.Checked = True Then
            ComboBox2.Visible = True
        End If
    End Sub

    Private Sub Service_Price_List_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ComboBox2.Visible = False
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        ComboBox1.Text = ""
        ComboBox2.Text = ""
        Price_List.Items.Clear()
        RadioButton1.Checked = False
        RadioButton2.Checked = False
    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox2.SelectedIndexChanged

    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        If RadioButton1.Checked = True Then
            ComboBox2.Visible = False
        End If
    End Sub
End Class