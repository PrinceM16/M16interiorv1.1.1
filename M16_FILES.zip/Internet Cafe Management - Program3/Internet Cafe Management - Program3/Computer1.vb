﻿Public Class Computer1

End Class