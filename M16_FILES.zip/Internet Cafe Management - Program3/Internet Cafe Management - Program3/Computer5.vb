﻿Public Class Computer5
    'Website: http://optiontech.blogspot.com
    'Name: Stopwatch
    'Description: This Stopwatch has two functions (1)Timer and (2)Countdown Timer.
    'You can adjust the speed from slow to real fast!
    'Author: Mario U. Malferrari Jr.
    'License: Free for personal use.
    'GIVE CREDITS TO THE REAL AUTHOR!

    Public Class frmStopwatch

        Sub SetTimer()
            If btnControl.Text = "Start" Then
                Timer1.Interval = txtSpeed.Value
                Timer1.Enabled = True
                btnControl.Text = "Stop"
            Else
                Timer1.Enabled = False
                btnControl.Text = "Start"
            End If
        End Sub

        Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
            Try
                System.Diagnostics.Process.Start("http://optiontech.blogspot.com")
            Catch ex As Exception
            End Try
        End Sub

        Private Sub btnControl_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnControl.Click
            SetTimer()
        End Sub

        Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
            If radTimer.Checked = True Then
                txtTime.Text = Format(txtTime.Text + 1, "00")
            ElseIf radCountdown.Checked = True Then
                If Integer.Parse(txtTime.Text) > 0 Then
                    txtTime.Text = Format(txtTime.Text - 1, "00")
                Else
                    Call SetTimer()
                    Beep()
                End If
            End If
        End Sub

        Private Sub btnReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReset.Click
            txtTime.Text = "00"
        End Sub

        Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
            Try
                System.Diagnostics.Process.Start("http://optiontech.blogspot.com")
            Catch ex As Exception
            End Try
            Application.Exit()
        End Sub

        Private Sub txtSpeed_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtSpeed.ValueChanged
            Timer1.Interval = txtSpeed.Value
        End Sub

        Private Sub radTimer_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles radTimer.Click
            Timer1.Enabled = False
            btnControl.Text = "Start"
            txtCountdown.Enabled = False
            txtCountdown.ReadOnly = True
        End Sub

        Private Sub radCountdown_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles radCountdown.Click
            Timer1.Enabled = False
            btnControl.Text = "Start"
            txtCountdown.Enabled = True
            txtCountdown.ReadOnly = False
        End Sub

        Private Sub txtCountdown_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCountdown.TextChanged
            txtTime.Text = Format(Integer.Parse(txtCountdown.Text), "00")
        End Sub

        Private Sub radTimer_CheckedChanged(sender As Object, e As EventArgs) Handles radTimer.CheckedChanged

        End Sub

        Private Sub txtTime_TextChanged(sender As Object, e As EventArgs) Handles txtTime.TextChanged

        End Sub
    End Class

End Class