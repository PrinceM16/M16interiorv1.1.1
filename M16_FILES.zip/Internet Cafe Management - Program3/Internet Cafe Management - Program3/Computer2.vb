﻿Public Class Computer2

End Class