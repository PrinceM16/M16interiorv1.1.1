﻿Public Class Computer3

End Class