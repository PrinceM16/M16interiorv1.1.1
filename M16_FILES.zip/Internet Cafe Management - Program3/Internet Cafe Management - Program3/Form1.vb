﻿Imports System
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Printing
Imports System.Windows.Forms

Public Class Form1
    Inherits System.Windows.Forms.Form


    Dim iTax As Decimal
    Dim ServiceTax As Decimal
    Dim PriceTax As Decimal
    Dim iSubTotal As Decimal
    Dim iTotalTotal As Decimal
    Dim itemcost(30) As Decimal
    Private rtbEditor As Object
    Const mcTax_Rate = 0.0
    Dim Diiscount As Decimal




    Private Sub Button33_Click(sender As Object, e As EventArgs)
        'The Button to exit 
        Dim Iexit As DialogResult
        Iexit = MessageBox.Show("Do you really want to quit this program", "Exit - Program", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning)

        If Iexit = Windows.Forms.DialogResult.Yes Then
            Application.Exit()
        End If
    End Sub

    Private Sub Change_Colour(sender As Object, e As EventArgs)
        'for the whole buttons to change
        Dim Allbutton As Button = sender
        Allbutton.BackColor = Color.Chocolate
    End Sub
    Private Sub Change_Control(sender As Object, e As EventArgs) Handles Button9.MouseEnter, Button8.MouseEnter, Button7.MouseEnter,
        Button6.MouseEnter, Button5.MouseEnter, Button4.MouseEnter, Button35.MouseEnter, Button34.MouseEnter, Button33.MouseEnter, Button3.MouseEnter, Button29.MouseEnter, Button28.MouseEnter,
        Button27.MouseEnter, Button26.MouseEnter, Button25.MouseEnter, Button24.MouseEnter, Button23.MouseEnter, Button22.MouseEnter,
        Button21.MouseEnter, Button20.MouseEnter, Button2.MouseEnter, Button19.MouseEnter, Button18.MouseEnter, Button17.MouseEnter,
        Button16.MouseEnter, Button15.MouseEnter, Button14.MouseEnter, Button13.MouseEnter, Button12.MouseEnter, Button11.MouseEnter,
        Button10.MouseEnter, Button1.MouseEnter
        'Declare for the whole buttons
        Dim Allbutton As Button = sender
        '
        Allbutton.BackColor = Color.FromKnownColor(KnownColor.Control)

    End Sub

    Private Sub Numbers_Only(sender As Object, e As KeyPressEventArgs) Handles TextBox6.KeyPress, TextBox5.KeyPress, TextBox4.KeyPress, TextBox3.KeyPress, TextBox29.KeyPress, TextBox28.KeyPress,
        TextBox27.KeyPress, TextBox26.KeyPress, TextBox25.KeyPress, TextBox24.KeyPress, TextBox23.KeyPress, TextBox22.KeyPress,
        TextBox21.KeyPress, TextBox20.KeyPress, TextBox2.KeyPress, TextBox19.KeyPress, TextBox18.KeyPress,
        TextBox17.KeyPress, TextBox16.KeyPress, TextBox15.KeyPress, TextBox14.KeyPress, TextBox13.KeyPress, TextBox12.KeyPress,
        TextBox11.KeyPress, TextBox10.KeyPress, TextBox7.KeyPress, TextBox8.KeyPress, TextBox9.KeyPress

        If Asc(e.KeyChar) <> 8 Then
            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                e.Handled = True
            End If
        End If

    End Sub

    Private Sub Button34_Click(sender As Object, e As EventArgs)
        For Each t In {TextBox1, TextBox10, TextBox11, TextBox12, TextBox13, TextBox14, TextBox15, TextBox16, TextBox6, TextBox5, TextBox4, TextBox3, TextBox29, TextBox28,
        TextBox27, TextBox26, TextBox25, TextBox24, TextBox23, TextBox22,
        TextBox21, TextBox20, TextBox2, TextBox19, TextBox18, TextBox9, TextBox8, TextBox7,
        TextBox17}

            t.Clear()

        Next
        Label1.Text = ""
        Label2.Text = ""
        Label3.Text = ""

        For Each R In {CheckBox1, CheckBox10, CheckBox11, CheckBox12, CheckBox13, CheckBox13, CheckBox14, CheckBox15, CheckBox16, CheckBox17, CheckBox18, CheckBox19, CheckBox2, CheckBox20, CheckBox21, CheckBox22, CheckBox23, CheckBox24, CheckBox25, CheckBox26, CheckBox27, CheckBox28, CheckBox29, CheckBox3, CheckBox9, CheckBox8, CheckBox7, CheckBox6, CheckBox5, CheckBox4}

            R.Checked = False
        Next

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For Each ene In {TextBox1, TextBox10, TextBox11, TextBox12, TextBox13, TextBox14, TextBox15, TextBox16, TextBox6, TextBox5, TextBox4,
       TextBox3, TextBox29, TextBox28, TextBox7, TextBox8, TextBox9,
       TextBox27, TextBox26, TextBox25, TextBox24, TextBox23, TextBox22,
       TextBox21, TextBox20, TextBox2, TextBox19, TextBox18,
       TextBox17, TextBox1}

            ene.Enabled = False

        Next
        Label1.Text = ""
        Label2.Text = ""
        Label3.Text = ""

        For Each R In {CheckBox1, CheckBox10, CheckBox11, CheckBox12, CheckBox13, CheckBox13, CheckBox14, CheckBox15, CheckBox16, CheckBox17, CheckBox18, CheckBox19, CheckBox2, CheckBox20, CheckBox21, CheckBox22, CheckBox23, CheckBox24, CheckBox25, CheckBox26, CheckBox27, CheckBox28, CheckBox29, CheckBox3, CheckBox9, CheckBox8, CheckBox7, CheckBox6, CheckBox5, CheckBox4}

            R.Enabled = False
        Next

    End Sub
    'Function for the button to enable checkbox - Button1 = CheckBox1
    Private Sub Button1_Click(sender As Object, e As EventArgs)
        CheckBox1.Enabled = True

    End Sub
    'Function for the button to enable checkbox - Button2 = CheckBox1
    Private Sub Button2_Click(sender As Object, e As EventArgs)
        CheckBox2.Enabled = True

    End Sub
    'Function for the button to enable checkbox - Button3 = CheckBox1
    Private Sub Button3_Click(sender As Object, e As EventArgs)
        CheckBox3.Enabled = True

    End Sub
    'Function for the button to enable checkbox - Button4 = CheckBox1
    Private Sub Button4_Click(sender As Object, e As EventArgs)
        CheckBox4.Enabled = True

    End Sub
    'Function for the button to enable checkbox - Button5 = CheckBox1
    Private Sub Button5_Click(sender As Object, e As EventArgs)
        CheckBox5.Enabled = True

    End Sub
    'Function for the button to enable checkbox - Button6 = CheckBox1
    Private Sub Button6_Click(sender As Object, e As EventArgs)
        CheckBox6.Enabled = True

    End Sub
    'Function for the button to enable checkbox - Button7 = CheckBox1
    Private Sub Button7_Click(sender As Object, e As EventArgs)
        CheckBox7.Enabled = True

    End Sub
    'Function for the button to enable checkbox - Button8 = CheckBox1
    Private Sub Button8_Click(sender As Object, e As EventArgs)
        CheckBox8.Enabled = True

    End Sub
    'Function for the button to enable checkbox - Button9 = CheckBox1
    Private Sub Button9_Click(sender As Object, e As EventArgs)
        CheckBox9.Enabled = True

    End Sub
    'Function for the button to enable checkbox - Button10 = CheckBox1
    Private Sub Button10_Click(sender As Object, e As EventArgs)
        CheckBox10.Enabled = True

    End Sub
    'Function for the button to enable checkbox - Button11 = CheckBox1
    Private Sub Button11_Click(sender As Object, e As EventArgs)
        CheckBox11.Enabled = True

    End Sub
    'Function for the button to enable checkbox - Button12= CheckBox1
    Private Sub Button12_Click(sender As Object, e As EventArgs)
        CheckBox12.Enabled = True

    End Sub
    'Function for the button to enable checkbox - Button13= CheckBox1
    Private Sub Button13_Click(sender As Object, e As EventArgs)
        CheckBox13.Enabled = True

    End Sub
    'Function for the button to enable checkbox - Button14= CheckBox1
    Private Sub Button14_Click(sender As Object, e As EventArgs)
        CheckBox14.Enabled = True

    End Sub
    'Function for the button to enable checkbox - Button15= CheckBox1
    Private Sub Button15_Click(sender As Object, e As EventArgs)
        CheckBox15.Enabled = True

    End Sub
    'Function for the button to enable checkbox - Button16= CheckBox1
    Private Sub Button16_Click(sender As Object, e As EventArgs)
        CheckBox16.Enabled = True

    End Sub
    'Function for the button to enable checkbox - Button17= CheckBox1
    Private Sub Button17_Click(sender As Object, e As EventArgs)
        CheckBox17.Enabled = True

    End Sub
    'Function for the button to enable checkbox - Button18= CheckBox1
    Private Sub Button18_Click(sender As Object, e As EventArgs)
        CheckBox18.Enabled = True

    End Sub
    'Function for the button to enable checkbox - Button19= CheckBox1
    Private Sub Button19_Click(sender As Object, e As EventArgs)
        CheckBox19.Enabled = True

    End Sub
    'Function for the button to enable checkbox - Button20 = CheckBox1
    Private Sub Button20_Click(sender As Object, e As EventArgs)
        CheckBox20.Enabled = True

    End Sub
    'Function for the button to enable checkbox - Button21 = CheckBox1
    Private Sub Button21_Click(sender As Object, e As EventArgs)
        CheckBox21.Enabled = True

    End Sub
    'Function for the button to enable checkbox - Button22 = CheckBox1
    Private Sub Button22_Click(sender As Object, e As EventArgs)
        CheckBox22.Enabled = True

    End Sub
    'Function for the button to enable checkbox - Button23 = CheckBox1
    Private Sub Button23_Click(sender As Object, e As EventArgs)
        CheckBox23.Enabled = True

    End Sub
    'Function for the button to enable checkbox - Button24 = CheckBox1
    Private Sub Button24_Click(sender As Object, e As EventArgs)
        CheckBox24.Enabled = True

    End Sub
    'Function for the button to enable checkbox - Button25 = CheckBox1
    Private Sub Button25_Click(sender As Object, e As EventArgs)
        CheckBox25.Enabled = True

    End Sub
    'Function for the button to enable checkbox - Button26 = CheckBox1
    Private Sub Button26_Click(sender As Object, e As EventArgs)
        CheckBox26.Enabled = True

    End Sub
    'Function for the button to enable checkbox - Button27 = CheckBox1
    Private Sub Button27_Click(sender As Object, e As EventArgs)
        CheckBox27.Enabled = True

    End Sub
    'Function for the button to enable checkbox - Button28 = CheckBox1
    Private Sub Button28_Click(sender As Object, e As EventArgs)
        CheckBox28.Enabled = True

    End Sub
    'Function for the button to enable checkbox - Button29 = CheckBox1
    Private Sub Button29_Click(sender As Object, e As EventArgs)
        CheckBox29.Enabled = True

    End Sub


    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox1 = TextBox1
    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs)

        TextBox1.Enabled = True
        TextBox1.Text = ""
        TextBox1.Focus()

    End Sub
    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox2 = TextBox1
    Private Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs)

        TextBox2.Enabled = True
        TextBox2.Text = ""
        TextBox2.Focus()

    End Sub
    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox3 = TextBox1
    Private Sub CheckBox3_CheckedChanged(sender As Object, e As EventArgs)

        TextBox3.Enabled = True
        TextBox3.Text = ""
        TextBox3.Focus()

    End Sub
    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox4 = TextBox1
    Private Sub CheckBox4_CheckedChanged(sender As Object, e As EventArgs)

        TextBox4.Enabled = True
        TextBox4.Text = ""
        TextBox4.Focus()

    End Sub
    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox5 = TextBox1
    Private Sub CheckBox5_CheckedChanged(sender As Object, e As EventArgs)

        TextBox5.Enabled = True
        TextBox5.Text = ""
        TextBox5.Focus()

    End Sub
    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox6 = TextBox1
    Private Sub CheckBox6_CheckedChanged(sender As Object, e As EventArgs)

        TextBox6.Enabled = True
        TextBox6.Text = ""
        TextBox6.Focus()

    End Sub
    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox7 = TextBox1
    Private Sub CheckBox7_CheckedChanged(sender As Object, e As EventArgs)

        TextBox7.Enabled = True
        TextBox7.Text = ""
        TextBox7.Focus()

    End Sub
    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox8 = TextBox1
    Private Sub CheckBox8_CheckedChanged(sender As Object, e As EventArgs)

        TextBox8.Enabled = True
        TextBox8.Text = ""
        TextBox8.Focus()

    End Sub
    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox9 = TextBox1
    Private Sub CheckBox9_CheckedChanged(sender As Object, e As EventArgs)

        TextBox9.Enabled = True
        TextBox9.Text = ""
        TextBox9.Focus()

    End Sub
    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox10 = TextBox1
    Private Sub CheckBox10_CheckedChanged(sender As Object, e As EventArgs)

        TextBox10.Enabled = True
        TextBox10.Text = ""
        TextBox10.Focus()

    End Sub
    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox11 = TextBox1
    Private Sub CheckBox11_CheckedChanged(sender As Object, e As EventArgs)

        TextBox11.Enabled = True
        TextBox11.Text = ""
        TextBox11.Focus()

    End Sub
    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox12 = TextBox1
    Private Sub CheckBox12_CheckedChanged(sender As Object, e As EventArgs)

        TextBox12.Enabled = True
        TextBox12.Text = ""
        TextBox12.Focus()

    End Sub
    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox13 = TextBox1
    Private Sub CheckBox13_CheckedChanged(sender As Object, e As EventArgs)

        TextBox13.Enabled = True
        TextBox13.Text = ""
        TextBox13.Focus()

    End Sub
    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox14 = TextBox1
    Private Sub CheckBox14_CheckedChanged(sender As Object, e As EventArgs)

        TextBox14.Enabled = True
        TextBox14.Text = ""
        TextBox14.Focus()

    End Sub
    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox15 = TextBox1
    Private Sub CheckBox15_CheckedChanged(sender As Object, e As EventArgs)

        TextBox15.Enabled = True
        TextBox15.Text = ""
        TextBox15.Focus()

    End Sub
    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox16 = TextBox1
    Private Sub CheckBox16_CheckedChanged(sender As Object, e As EventArgs)

        TextBox16.Enabled = True
        TextBox16.Text = ""
        TextBox16.Focus()

    End Sub
    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox17 = TextBox1
    Private Sub CheckBox17_CheckedChanged(sender As Object, e As EventArgs)

        TextBox17.Enabled = True
        TextBox17.Text = ""
        TextBox17.Focus()

    End Sub
    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox18 = TextBox1
    Private Sub CheckBox18_CheckedChanged(sender As Object, e As EventArgs)

        TextBox18.Enabled = True
        TextBox18.Text = ""
        TextBox18.Focus()

    End Sub
    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox19 = TextBox1
    Private Sub CheckBox19_CheckedChanged(sender As Object, e As EventArgs)

        TextBox19.Enabled = True
        TextBox19.Text = ""
        TextBox19.Focus()

    End Sub
    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox20 = TextBox1
    Private Sub CheckBox20_CheckedChanged(sender As Object, e As EventArgs)

        TextBox20.Enabled = True
        TextBox20.Text = ""
        TextBox20.Focus()

    End Sub
    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox21 = TextBox1
    Private Sub CheckBox21_CheckedChanged(sender As Object, e As EventArgs)

        TextBox21.Enabled = True
        TextBox21.Text = ""
        TextBox21.Focus()

    End Sub
    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox22 = TextBox1
    Private Sub CheckBox22_CheckedChanged(sender As Object, e As EventArgs)

        TextBox22.Enabled = True
        TextBox22.Text = ""
        TextBox22.Focus()

    End Sub
    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox23 = TextBox1
    Private Sub CheckBox23_CheckedChanged(sender As Object, e As EventArgs)

        TextBox23.Enabled = True
        TextBox23.Text = ""
        TextBox23.Focus()

    End Sub
    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox24 = TextBox1
    Private Sub CheckBox24_CheckedChanged(sender As Object, e As EventArgs)

        TextBox24.Enabled = True
        TextBox24.Text = ""
        TextBox24.Focus()

    End Sub
    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox25 = TextBox1
    Private Sub CheckBox25_CheckedChanged(sender As Object, e As EventArgs)

        TextBox25.Enabled = True
        TextBox25.Text = ""
        TextBox25.Focus()

    End Sub
    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox26 = TextBox1
    Private Sub CheckBox26_CheckedChanged(sender As Object, e As EventArgs)

        TextBox26.Enabled = True
        TextBox26.Text = ""
        TextBox26.Focus()

    End Sub
    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox27 = TextBox1
    Private Sub CheckBox27_CheckedChanged(sender As Object, e As EventArgs)

        TextBox27.Enabled = True
        TextBox27.Text = ""
        TextBox27.Focus()

    End Sub
    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox28 = TextBox1
    Private Sub CheckBox28_CheckedChanged(sender As Object, e As EventArgs)

        TextBox28.Enabled = True
        TextBox28.Text = ""
        TextBox28.Focus()

    End Sub
    'Function of checkbox enabled to enable the textbox and allow the user to fill the entities
    'Function for the checkbox - CheckBox29 = TextBox1
    Private Sub CheckBox29_CheckedChanged(sender As Object, e As EventArgs)

        TextBox29.Enabled = True
        TextBox29.Text = ""
        TextBox29.Focus()

    End Sub


    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)

        If TextBox1.Text = "0" Then
            TextBox1.Enabled = False
            CheckBox1.Checked = False
            CheckBox1.Enabled = False
        End If

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs)

        If TextBox2.Text = "0" Then
            TextBox2.Enabled = False
            CheckBox2.Checked = False
            CheckBox2.Enabled = False
        End If

    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs)

        If TextBox3.Text = "0" Then
            TextBox3.Enabled = False
            CheckBox3.Checked = False
            CheckBox3.Enabled = False
        End If

    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs)
        If TextBox4.Text = "0" Then
            TextBox4.Enabled = False
            CheckBox4.Checked = False
            CheckBox4.Enabled = False
        End If

    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs)

        If TextBox5.Text = "0" Then
            TextBox5.Enabled = False
            CheckBox5.Checked = False
            CheckBox5.Enabled = False
        End If

    End Sub

    Private Sub TextBox6_TextChanged(sender As Object, e As EventArgs)

        If TextBox6.Text = "0" Then
            TextBox6.Enabled = False
            CheckBox6.Checked = False
            CheckBox6.Enabled = False
        End If

    End Sub

    Private Sub TextBox7_TextChanged(sender As Object, e As EventArgs)

        If TextBox7.Text = "0" Then
            TextBox7.Enabled = False
            CheckBox7.Checked = False
            CheckBox7.Enabled = False
        End If

    End Sub

    Private Sub TextBox8_TextChanged(sender As Object, e As EventArgs)

        If TextBox8.Text = "0" Then
            TextBox8.Enabled = False
            CheckBox8.Checked = False
            CheckBox8.Enabled = False

        End If

    End Sub

    Private Sub TextBox9_TextChanged(sender As Object, e As EventArgs)

        If TextBox9.Text = "0" Then
            TextBox9.Enabled = False
            CheckBox9.Checked = False
            CheckBox9.Enabled = False
        End If

    End Sub

    Private Sub TextBox10_TextChanged(sender As Object, e As EventArgs)

        If TextBox10.Text = "0" Then
            TextBox10.Enabled = False
            CheckBox10.Checked = False
            CheckBox10.Enabled = False
        End If

    End Sub

    Private Sub TextBox11_TextChanged(sender As Object, e As EventArgs)


        If TextBox11.Text = "0" Then
            TextBox11.Enabled = False
            CheckBox11.Checked = False
            CheckBox11.Enabled = False
        End If

    End Sub

    Private Sub TextBox12_TextChanged(sender As Object, e As EventArgs)

        If TextBox12.Text = "0" Then
            TextBox12.Enabled = False
            CheckBox12.Checked = False
            CheckBox12.Enabled = False
        End If

    End Sub

    Private Sub TextBox13_TextChanged(sender As Object, e As EventArgs)

        If TextBox13.Text = "0" Then
            TextBox13.Enabled = False
            CheckBox13.Checked = False
            CheckBox13.Enabled = False

        End If

    End Sub

    Private Sub TextBox14_TextChanged(sender As Object, e As EventArgs)

        If TextBox14.Text = "0" Then
            TextBox14.Enabled = False
            CheckBox14.Checked = False
            CheckBox14.Enabled = False
        End If

    End Sub

    Private Sub TextBox15_TextChanged(sender As Object, e As EventArgs)


        If TextBox15.Text = "0" Then
            TextBox15.Enabled = False
            CheckBox15.Checked = False
            CheckBox15.Enabled = False
        End If

    End Sub

    Private Sub TextBox16_TextChanged(sender As Object, e As EventArgs)

        If TextBox16.Text = "0" Then
            TextBox16.Enabled = False
            CheckBox16.Checked = False
            CheckBox16.Enabled = False
        End If

    End Sub

    Private Sub TextBox17_TextChanged(sender As Object, e As EventArgs)

        If TextBox17.Text = "0" Then
            TextBox17.Enabled = False
            CheckBox17.Checked = False
            CheckBox17.Enabled = False
        End If

    End Sub

    Private Sub TextBox18_TextChanged(sender As Object, e As EventArgs)

        If TextBox18.Text = "0" Then
            TextBox18.Enabled = False
            CheckBox18.Checked = False
            CheckBox18.Enabled = False
        End If

    End Sub

    Private Sub TextBox19_TextChanged(sender As Object, e As EventArgs)

        If TextBox19.Text = "0" Then
            TextBox19.Enabled = False
            CheckBox19.Checked = False
            CheckBox19.Enabled = False
        End If

    End Sub

    Private Sub TextBox20_TextChanged(sender As Object, e As EventArgs)

        If TextBox20.Text = "0" Then
            TextBox20.Enabled = False
            CheckBox20.Checked = False
            CheckBox20.Enabled = False
        End If

    End Sub

    Private Sub TextBox21_TextChanged(sender As Object, e As EventArgs)

        If TextBox21.Text = "0" Then
            TextBox21.Enabled = False
            CheckBox21.Checked = False
            CheckBox21.Enabled = False
        End If

    End Sub

    Private Sub TextBox22_TextChanged(sender As Object, e As EventArgs)

        If TextBox22.Text = "0" Then
            TextBox22.Enabled = False
            CheckBox22.Checked = False
            CheckBox22.Enabled = False
        End If

    End Sub

    Private Sub TextBox23_TextChanged(sender As Object, e As EventArgs)

        If TextBox23.Text = "0" Then
            TextBox23.Enabled = False
            CheckBox23.Checked = False
            CheckBox23.Enabled = False
        End If

    End Sub

    Private Sub TextBox24_TextChanged(sender As Object, e As EventArgs)

        If TextBox24.Text = "0" Then
            TextBox24.Enabled = False
            CheckBox24.Checked = False
            CheckBox24.Enabled = False
        End If

    End Sub

    Private Sub TextBox25_TextChanged(sender As Object, e As EventArgs)

        If TextBox25.Text = "0" Then
            TextBox25.Enabled = False
            CheckBox25.Checked = False
            CheckBox25.Enabled = False
        End If

    End Sub

    Private Sub TextBox26_TextChanged(sender As Object, e As EventArgs)

        If TextBox26.Text = "0" Then
            TextBox26.Enabled = False
            CheckBox26.Checked = False
            CheckBox26.Enabled = False
        End If

    End Sub

    Private Sub TextBox27_TextChanged(sender As Object, e As EventArgs)

        If TextBox27.Text = "0" Then
            TextBox27.Enabled = False
            CheckBox27.Checked = False
            CheckBox27.Enabled = False
        End If

    End Sub


    Private Sub TextBox28_TextChanged(sender As Object, e As EventArgs)

        If TextBox28.Text = "0" Then
            TextBox28.Enabled = False
            CheckBox28.Checked = False
            CheckBox28.Enabled = False
        End If

    End Sub

    Private Sub TextBox29_TextChanged(sender As Object, e As EventArgs)

        If TextBox29.Text = "0" Then
            TextBox29.Enabled = False
            CheckBox29.Checked = False
            CheckBox29.Enabled = False
        End If

    End Sub




    Private Sub Form1_MouseHover(sender As Object, e As EventArgs)

    End Sub


    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs)

    End Sub

    Private Sub Label7_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Form1_MouseMove(sender As Object, e As MouseEventArgs)

    End Sub

    Private Sub Enter_Zero(sender As Object, e As EventArgs) Handles MyBase.MouseHover, GroupBox3.MouseHover, GroupBox1.MouseHover, Me.MouseHover

        For Each txt In {TextBox1, TextBox10, TextBox11, TextBox12, TextBox13, TextBox14, TextBox15, TextBox16, TextBox6, TextBox5, TextBox4, TextBox3, TextBox29, TextBox28,
      TextBox27, TextBox26, TextBox25, TextBox24, TextBox23, TextBox22,
      TextBox21, TextBox20, TextBox2, TextBox19, TextBox18,
      TextBox17, TextBox7, TextBox8, TextBox9}

            If txt.Text = "" Then
                txt.Text = "0"
            End If

        Next

    End Sub

    Private Sub TextBox1_TextChanged_1(sender As Object, e As EventArgs)
        If CheckBox1.Checked = False And TextBox1.Text = "0" Then
            CheckBox1.Checked = False
            CheckBox1.Enabled = False
            TextBox1.Enabled = False
        End If

    End Sub

    Private Sub TextBox2_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

        If CheckBox2.Checked = False And TextBox2.Text = "0" Then
            CheckBox2.Checked = False
            CheckBox2.Enabled = False
            TextBox2.Enabled = False
        End If

    End Sub

    Private Sub TextBox3_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox3.TextChanged

        If CheckBox3.Checked = False And TextBox3.Text = "0" Then
            CheckBox3.Checked = False
            CheckBox3.Enabled = False
            TextBox3.Enabled = False
        End If

    End Sub

    Private Sub TextBox4_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        If CheckBox4.Checked = False And TextBox4.Text = "0" Then
            CheckBox4.Checked = False
            CheckBox4.Enabled = False
            TextBox4.Enabled = False
        End If

    End Sub

    Private Sub TextBox5_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        If CheckBox5.Checked = False And TextBox4.Text = "0" Then
            CheckBox5.Checked = False
            CheckBox5.Enabled = False
            TextBox5.Enabled = False
        End If

    End Sub

    Private Sub TextBox6_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        If CheckBox6.Checked = False And TextBox4.Text = "0" Then
            CheckBox6.Checked = False
            CheckBox6.Enabled = False
            TextBox6.Enabled = False
        End If

    End Sub

    Private Sub TextBox7_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        If CheckBox7.Checked = False And TextBox4.Text = "0" Then
            CheckBox7.Checked = False
            CheckBox7.Enabled = False
            TextBox4.Enabled = False
        End If

    End Sub

    Private Sub TextBox8_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        If CheckBox8.Checked = False And TextBox4.Text = "0" Then
            CheckBox8.Checked = False
            CheckBox8.Enabled = False
            TextBox8.Enabled = False
        End If

    End Sub

    Private Sub TextBox9_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        If CheckBox9.Checked = False And TextBox4.Text = "0" Then
            CheckBox9.Checked = False
            CheckBox9.Enabled = False
            TextBox9.Enabled = False
        End If

    End Sub


    Private Sub TextBox10_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        If CheckBox10.Checked = False And TextBox4.Text = "0" Then
            CheckBox10.Checked = False
            CheckBox10.Enabled = False
            TextBox10.Enabled = False
        End If

    End Sub

    Private Sub TextBox11_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        If CheckBox11.Checked = False And TextBox4.Text = "0" Then
            CheckBox11.Checked = False
            CheckBox11.Enabled = False
            TextBox11.Enabled = False
        End If

    End Sub

    Private Sub TextBox12_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        If CheckBox12.Checked = False And TextBox4.Text = "0" Then
            CheckBox12.Checked = False
            CheckBox12.Enabled = False
            TextBox12.Enabled = False
        End If

    End Sub

    Private Sub TextBox13_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        If CheckBox13.Checked = False And TextBox4.Text = "0" Then
            CheckBox13.Checked = False
            CheckBox13.Enabled = False
            TextBox13.Enabled = False
        End If

    End Sub

    Private Sub TextBox14_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        If CheckBox14.Checked = False And TextBox4.Text = "0" Then
            CheckBox14.Checked = False
            CheckBox14.Enabled = False
            TextBox14.Enabled = False
        End If

    End Sub

    Private Sub TextBox15_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        If CheckBox15.Checked = False And TextBox4.Text = "0" Then
            CheckBox15.Checked = False
            CheckBox15.Enabled = False
            TextBox15.Enabled = False
        End If

    End Sub

    Private Sub TextBox16_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        If CheckBox16.Checked = False And TextBox4.Text = "0" Then
            CheckBox16.Checked = False
            CheckBox16.Enabled = False
            TextBox16.Enabled = False
        End If

    End Sub

    Private Sub TextBox17_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        If CheckBox17.Checked = False And TextBox4.Text = "0" Then
            CheckBox17.Checked = False
            CheckBox17.Enabled = False
            TextBox17.Enabled = False
        End If

    End Sub

    Private Sub TextBox18_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        If CheckBox18.Checked = False And TextBox4.Text = "0" Then
            CheckBox18.Checked = False
            CheckBox18.Enabled = False
            TextBox18.Enabled = False
        End If

    End Sub

    Private Sub TextBox19_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        If CheckBox19.Checked = False And TextBox4.Text = "0" Then
            CheckBox19.Checked = False
            CheckBox19.Enabled = False
            TextBox19.Enabled = False
        End If

    End Sub

    Private Sub TextBox20_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        If CheckBox20.Checked = False And TextBox4.Text = "0" Then
            CheckBox20.Checked = False
            CheckBox20.Enabled = False
            TextBox20.Enabled = False
        End If

    End Sub

    Private Sub TextBox21_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        If CheckBox21.Checked = False And TextBox4.Text = "0" Then
            CheckBox21.Checked = False
            CheckBox21.Enabled = False
            TextBox21.Enabled = False
        End If

    End Sub

    Private Sub TextBox22_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        If CheckBox22.Checked = False And TextBox4.Text = "0" Then
            CheckBox22.Checked = False
            CheckBox22.Enabled = False
            TextBox22.Enabled = False
        End If

    End Sub

    Private Sub TextBox23_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        If CheckBox23.Checked = False And TextBox4.Text = "0" Then
            CheckBox23.Checked = False
            CheckBox23.Enabled = False
            TextBox23.Enabled = False
        End If

    End Sub

    Private Sub TextBox24_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        If CheckBox24.Checked = False And TextBox4.Text = "0" Then
            CheckBox24.Checked = False
            CheckBox24.Enabled = False
            TextBox24.Enabled = False
        End If

    End Sub

    Private Sub TextBox25_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        If CheckBox25.Checked = False And TextBox4.Text = "0" Then
            CheckBox25.Checked = False
            CheckBox25.Enabled = False
            TextBox25.Enabled = False
        End If

    End Sub

    Private Sub TextBox26_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        If CheckBox26.Checked = False And TextBox4.Text = "0" Then
            CheckBox26.Checked = False
            CheckBox26.Enabled = False
            TextBox26.Enabled = False
        End If

    End Sub


    Private Sub TextBox27_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        If CheckBox27.Checked = False And TextBox4.Text = "0" Then
            CheckBox27.Checked = False
            CheckBox27.Enabled = False
            TextBox27.Enabled = False
        End If

    End Sub

    Private Sub TextBox28_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        If CheckBox28.Checked = False And TextBox4.Text = "0" Then
            CheckBox28.Checked = False
            CheckBox28.Enabled = False
            TextBox28.Enabled = False
        End If

    End Sub

    Private Sub TextBox29_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        If CheckBox29.Checked = False And TextBox4.Text = "0" Then
            CheckBox29.Checked = False
            CheckBox29.Enabled = False
            TextBox29.Enabled = False
        End If

    End Sub





    Private Sub Button35_Click(sender As Object, e As EventArgs) Handles Button35.Click

        'Dim LocalFormat As NumberFormatInfo = CType(NumberFormatInfo.CurrentInfo.Clone(), NumberFormatInfo)



        itemcost(1) = Convert.ToDecimal(TextBox1.Text) * 0.41 '-For the Internet
        itemcost(2) = Convert.ToDecimal(TextBox2.Text) * 2.0 '-For the Copies B/W 
        itemcost(3) = Convert.ToDecimal(TextBox3.Text) * 4.0 '-For the Copies Colour
        itemcost(4) = Convert.ToDecimal(TextBox4.Text) * 3.0 '-For the Printing per Black / White paper
        itemcost(5) = Convert.ToDecimal(TextBox5.Text) * 6.0 '-For the Printing per Colour Paper
        itemcost(6) = Convert.ToDecimal(TextBox6.Text) * 10.0 '-For the A3 B/W Copies
        itemcost(7) = Convert.ToDecimal(TextBox7.Text) * 15.0 '-For the business cards 
        itemcost(8) = Convert.ToDecimal(TextBox8.Text) * 10.0  '-For the A3 Prints out
        itemcost(9) = Convert.ToDecimal(TextBox9.Text) * 13.0  '-For the Colour Prints Out A3
        itemcost(10) = Convert.ToDecimal(TextBox10.Text) * 13.0  '-For the Number of Typed Documentsv
        itemcost(11) = Convert.ToDecimal(TextBox11.Text) * 10.0  '-For theNumber of Edited Pages
        itemcost(12) = Convert.ToDecimal(TextBox12.Text) * 13.0  '-For the Number of Assignment pages
        itemcost(13) = Convert.ToDecimal(TextBox13.Text) * 100.0  '-For the Number of the Invoices
        itemcost(14) = Convert.ToDecimal(TextBox14.Text) * 20.0  '-For the  Number of WiFi Vouchers 
        itemcost(15) = Convert.ToDecimal(TextBox15.Text) * 375.0  '-For the Number of Logo Designs
        itemcost(16) = Convert.ToDecimal(TextBox16.Text) * 100.0  '-For the Number of the Company LetterHeads
        itemcost(17) = Convert.ToDecimal(TextBox17.Text) * 1.5  '-For the  Number of Flyers
        itemcost(18) = Convert.ToDecimal(TextBox18.Text) * 160.0  '-For the  Number of 3D house Plans Visualizations
        itemcost(19) = Convert.ToDecimal(TextBox19.Text) * 120.0  '-For the Number of Invoice Designs
        itemcost(20) = Convert.ToDecimal(TextBox20.Text) * 450.0  '-For the  Number of the Company Registrations
        itemcost(21) = Convert.ToDecimal(TextBox21.Text) * 0.65  '-For the Number of 2500 6D Flyers Glossy Papers
        itemcost(22) = Convert.ToDecimal(TextBox22.Text) * 1.15  '-For the Number of 5000 6D Flyers Glossy Papers
        itemcost(23) = Convert.ToDecimal(TextBox23.Text) * 8.0  '-For the Number of A4 Laminated Flyers
        itemcost(24) = Convert.ToDecimal(TextBox24.Text) * 15.0  '-For the Number of A3 B/W Laminated
        itemcost(25) = Convert.ToDecimal(TextBox25.Text) * 2.5  '-For the Number of A4 File Pockets 
        itemcost(26) = Convert.ToDecimal(TextBox26.Text) * 3.5  '-For the Number of A4 Brown Envelopes
        itemcost(27) = Convert.ToDecimal(TextBox27.Text) * 80.0  '-For the Number of 8GB USB Drives
        itemcost(28) = Convert.ToDecimal(TextBox28.Text) * 40.0  '-For the Number of Big Value Packs
        itemcost(29) = Convert.ToDecimal(TextBox29.Text) * 20.0  '-For the Online Registrations

        itemcost(30) = (itemcost(1) + itemcost(2) + itemcost(3) + itemcost(4) + itemcost(5) + itemcost(6) + itemcost(7) + itemcost(8) + itemcost(9) + itemcost(10) + itemcost(11) + itemcost(12) + itemcost(13) + itemcost(14) + itemcost(15) + itemcost(16) + itemcost(17) + itemcost(18) + itemcost(19) + itemcost(20) + itemcost(21) + itemcost(22) + itemcost(23) + itemcost(24) + itemcost(25) + itemcost(26) + itemcost(27) + itemcost(28) + itemcost(29))

        iTax = cFindTax(itemcost(30))

        Label2.Text = itemcost(30)

        Label2.Text = FormatCurrency(iTax)
        Label1.Text = FormatCurrency(itemcost(30))
        Label3.Text = FormatCurrency(itemcost(30) - iTax)

        RichTextBox1.SelectedText = Convert.ToString("The Price Recipt") & ControlChars.NewLine
        RichTextBox1.SelectedText = "|=================================================|" & ControlChars.NewLine & ControlChars.NewLine



        If CheckBox1.Checked = True Then
            RichTextBox1.SelectedText = " The Internet used for: " & " " & TextBox1.Text & " " & "Minutes" & ControlChars.NewLine & FormatCurrency(itemcost(1)) & ControlChars.NewLine & ControlChars.NewLine

        End If

        If CheckBox2.Checked = True Then
            RichTextBox1.SelectedText = " The B/W Copies A4 Out:" & " " & TextBox2.Text & ControlChars.NewLine & FormatCurrency(itemcost(2)) & ControlChars.NewLine & ControlChars.NewLine
        End If

        If CheckBox3.Checked = True Then
            RichTextBox1.SelectedText = " The Colour Copies A4 Out: " & " " & TextBox3.Text & ControlChars.NewLine & FormatCurrency(itemcost(3)) & ControlChars.NewLine & ControlChars.NewLine

        End If

        If CheckBox4.Checked = True Then
            RichTextBox1.SelectedText = " The B/W Prints A4 Out: " & " " & TextBox4.Text & ControlChars.NewLine & FormatCurrency(itemcost(4)) & ControlChars.NewLine & ControlChars.NewLine

        End If
        If CheckBox5.Checked = True Then
            RichTextBox1.SelectedText = " The Colour Prints A4 Out: " & " " & TextBox5.Text & ControlChars.NewLine & FormatCurrency(itemcost(5)) & ControlChars.NewLine & ControlChars.NewLine

        End If
        If CheckBox6.Checked = True Then
            RichTextBox1.SelectedText = " The B/W Copies Out A3: " & " " & TextBox6.Text & ControlChars.NewLine & FormatCurrency(itemcost(6)) & ControlChars.NewLine & ControlChars.NewLine

        End If
        If CheckBox7.Checked = True Then
            RichTextBox1.SelectedText = " The Business Cards: " & " " & TextBox7.Text & ControlChars.NewLine & FormatCurrency(itemcost(7)) & ControlChars.NewLine & ControlChars.NewLine

        End If
        If CheckBox8.Checked = True Then
            RichTextBox1.SelectedText = " The B/W Prints Out A3: " & " " & TextBox8.Text & ControlChars.NewLine & FormatCurrency(itemcost(8)) & ControlChars.NewLine & ControlChars.NewLine

        End If
        If CheckBox9.Checked = True Then
            RichTextBox1.SelectedText = " The Colour Prints Out A3: " & " " & TextBox9.Text & ControlChars.NewLine & FormatCurrency(itemcost(9)) & ControlChars.NewLine & ControlChars.NewLine

        End If
        If CheckBox10.Checked = True Then
            RichTextBox1.SelectedText = " The Number of Typed Documents: " & " " & TextBox10.Text & ControlChars.NewLine & FormatCurrency(itemcost(10)) & ControlChars.NewLine & ControlChars.NewLine

        End If
        If CheckBox11.Checked = True Then
            RichTextBox1.SelectedText = " The Number of Edited Pages: " & " " & TextBox11.Text & ControlChars.NewLine & FormatCurrency(itemcost(11)) & ControlChars.NewLine & ControlChars.NewLine

        End If
        If CheckBox12.Checked = True Then
            RichTextBox1.SelectedText = " The Number of Assignment pages: " & " " & TextBox12.Text & ControlChars.NewLine & FormatCurrency(itemcost(12)) & ControlChars.NewLine & ControlChars.NewLine

        End If
        If CheckBox13.Checked = True Then
            RichTextBox1.SelectedText = " The Number of the Invoices: " & " " & TextBox13.Text & ControlChars.NewLine & FormatCurrency(itemcost(13)) & ControlChars.NewLine & ControlChars.NewLine

        End If
        If CheckBox14.Checked = True Then
            RichTextBox1.SelectedText = " The Number of WiFi Vouchers: " & " " & TextBox14.Text & ControlChars.NewLine & FormatCurrency(itemcost(14)) & ControlChars.NewLine & ControlChars.NewLine

        End If
        If CheckBox15.Checked = True Then
            RichTextBox1.SelectedText = " The Number of Logo Designs:" & " " & TextBox15.Text & ControlChars.NewLine & FormatCurrency(itemcost(15)) & ControlChars.NewLine & ControlChars.NewLine

        End If
        If CheckBox16.Checked = True Then
            RichTextBox1.SelectedText = " The Number of the Company LetterHeads: " & " " & TextBox16.Text & ControlChars.NewLine & FormatCurrency(itemcost(16)) & ControlChars.NewLine & ControlChars.NewLine

        End If
        If CheckBox17.Checked = True Then
            RichTextBox1.SelectedText = " The Number of Flyers: " & " " & TextBox17.Text & ControlChars.NewLine & FormatCurrency(itemcost(17)) & ControlChars.NewLine & ControlChars.NewLine

        End If
        If CheckBox18.Checked = True Then
            RichTextBox1.SelectedText = " The Number of 3D house Plans Visualizations: " & " " & TextBox18.Text & ControlChars.NewLine & FormatCurrency(itemcost(18)) & ControlChars.NewLine & ControlChars.NewLine

        End If
        If CheckBox19.Checked = True Then
            RichTextBox1.SelectedText = " The Number of Invoice Designs:  " & " " & TextBox19.Text & ControlChars.NewLine & FormatCurrency(itemcost(19)) & ControlChars.NewLine & ControlChars.NewLine

        End If
        If CheckBox20.Checked = True Then
            RichTextBox1.SelectedText = " The Number of the Company Registrations: " & " " & TextBox20.Text & ControlChars.NewLine & FormatCurrency(itemcost(20)) & ControlChars.NewLine & ControlChars.NewLine

        End If
        If CheckBox21.Checked = True Then
            RichTextBox1.SelectedText = " The Number of 2500 6D Flyers Glossy Papers: " & " " & TextBox21.Text & ControlChars.NewLine & FormatCurrency(itemcost(21)) & ControlChars.NewLine & ControlChars.NewLine

        End If
        If CheckBox22.Checked = True Then
            RichTextBox1.SelectedText = " The Number of 5000 6D Flyers Glossy Papers: " & " " & TextBox22.Text & ControlChars.NewLine & FormatCurrency(itemcost(22)) & ControlChars.NewLine & ControlChars.NewLine

        End If
        If CheckBox23.Checked = True Then
            RichTextBox1.SelectedText = " The Number of A4 Laminated Flyers: " & " " & TextBox23.Text & ControlChars.NewLine & FormatCurrency(itemcost(23)) & ControlChars.NewLine & ControlChars.NewLine

        End If
        If CheckBox24.Checked = True Then
            RichTextBox1.SelectedText = " The Number of A3 B/W Laminated: Flyers " & " " & TextBox24.Text & ControlChars.NewLine & FormatCurrency(itemcost(24)) & ControlChars.NewLine & ControlChars.NewLine

        End If
        If CheckBox25.Checked = True Then
            RichTextBox1.SelectedText = " The Number of A4 File Pockets: " & " " & TextBox25.Text & ControlChars.NewLine & FormatCurrency(itemcost(25)) & ControlChars.NewLine & ControlChars.NewLine

        End If
        If CheckBox26.Checked = True Then
            RichTextBox1.SelectedText = " The Number of A4 Brown Envelopes: " & " " & TextBox26.Text & ControlChars.NewLine & FormatCurrency(itemcost(26)) & ControlChars.NewLine & ControlChars.NewLine

        End If
        If CheckBox27.Checked = True Then
            RichTextBox1.SelectedText = " The Number of 8GB USB Drives: " & " " & TextBox27.Text & ControlChars.NewLine & FormatCurrency(itemcost(27)) & ControlChars.NewLine & ControlChars.NewLine

        End If
        If CheckBox28.Checked = True Then
            RichTextBox1.SelectedText = " The Number of Big Value Packs: " & " " & TextBox28.Text & ControlChars.NewLine & FormatCurrency(itemcost(28)) & ControlChars.NewLine & ControlChars.NewLine

        End If
        If CheckBox29.Checked = True Then
            RichTextBox1.SelectedText = " For Online Registrations:" & " " & TextBox29.Text & ControlChars.NewLine & FormatCurrency(itemcost(29)) & ControlChars.NewLine & ControlChars.NewLine

        End If

        RichTextBox1.SelectedText = "|==================================================|" & ControlChars.NewLine & ControlChars.NewLine

        RichTextBox1.SelectedText = " Sub Total:" & "    " & Label1.Text & ControlChars.NewLine & ControlChars.NewLine
        RichTextBox1.SelectedText = "____________________________________________________"

        RichTextBox1.SelectedText = "Discount:" & "     " & Label3.Text & ControlChars.NewLine & ControlChars.NewLine


        RichTextBox1.SelectedText = "____________________________________________________"
        RichTextBox1.SelectedText = "Total Amount:" & "    " & Label2.Text & ControlChars.NewLine & ControlChars.NewLine
        RichTextBox1.SelectedText = "===================================================."



    End Sub
    Private Function cFindTax(ByVal cAmount As Decimal) As Decimal

        cFindTax = cAmount - (cAmount * mcTax_Rate)

    End Function



    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        CheckBox1.Enabled = True
    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click

        CheckBox2.Enabled = True
    End Sub

    Private Sub Button3_Click_1(sender As Object, e As EventArgs) Handles Button3.Click

        CheckBox3.Enabled = True
    End Sub

    Private Sub Button4_Click_1(sender As Object, e As EventArgs) Handles Button4.Click

        CheckBox4.Enabled = True
    End Sub

    Private Sub Button5_Click_1(sender As Object, e As EventArgs) Handles Button5.Click

        CheckBox5.Enabled = True
    End Sub

    Private Sub Button6_Click_1(sender As Object, e As EventArgs) Handles Button6.Click

        CheckBox6.Enabled = True
    End Sub

    Private Sub Button7_Click_1(sender As Object, e As EventArgs) Handles Button7.Click

        CheckBox7.Enabled = True
    End Sub

    Private Sub Button8_Click_1(sender As Object, e As EventArgs) Handles Button8.Click

        CheckBox8.Enabled = True
    End Sub

    Private Sub Button9_Click_1(sender As Object, e As EventArgs) Handles Button9.Click



        CheckBox9.Enabled = True
    End Sub

    Private Sub Button10_Click_1(sender As Object, e As EventArgs) Handles Button10.Click

        CheckBox10.Enabled = True
    End Sub

    Private Sub Button11_Click_1(sender As Object, e As EventArgs) Handles Button11.Click

        CheckBox11.Enabled = True
    End Sub

    Private Sub Button12_Click_1(sender As Object, e As EventArgs) Handles Button12.Click

        CheckBox12.Enabled = True
    End Sub

    Private Sub Button13_Click_1(sender As Object, e As EventArgs) Handles Button13.Click

        CheckBox13.Enabled = True
    End Sub

    Private Sub Button14_Click_1(sender As Object, e As EventArgs) Handles Button14.Click

        CheckBox14.Enabled = True
    End Sub

    Private Sub Button15_Click_1(sender As Object, e As EventArgs) Handles Button15.Click

        CheckBox15.Enabled = True
    End Sub

    Private Sub Button16_Click_1(sender As Object, e As EventArgs) Handles Button16.Click

        CheckBox16.Enabled = True
    End Sub

    Private Sub Button17_Click_1(sender As Object, e As EventArgs) Handles Button17.Click

        CheckBox17.Enabled = True
    End Sub

    Private Sub Button18_Click_1(sender As Object, e As EventArgs) Handles Button18.Click

        CheckBox18.Enabled = True
    End Sub

    Private Sub Button19_Click_1(sender As Object, e As EventArgs) Handles Button19.Click

        CheckBox19.Enabled = True
    End Sub

    Private Sub Button20_Click_1(sender As Object, e As EventArgs) Handles Button20.Click

        CheckBox20.Enabled = True
    End Sub

    Private Sub Button21_Click_1(sender As Object, e As EventArgs) Handles Button21.Click

        CheckBox21.Enabled = True
    End Sub

    Private Sub Button22_Click_1(sender As Object, e As EventArgs) Handles Button22.Click

        CheckBox22.Enabled = True
    End Sub

    Private Sub Button23_Click_1(sender As Object, e As EventArgs) Handles Button23.Click

        CheckBox23.Enabled = True
    End Sub

    Private Sub Button25_Click_1(sender As Object, e As EventArgs) Handles Button25.Click


        CheckBox25.Enabled = True
    End Sub

    Private Sub Button26_Click_1(sender As Object, e As EventArgs) Handles Button26.Click

        CheckBox26.Enabled = True
    End Sub

    Private Sub Button27_Click_1(sender As Object, e As EventArgs) Handles Button27.Click

        CheckBox27.Enabled = True
    End Sub

    Private Sub Button28_Click_1(sender As Object, e As EventArgs) Handles Button28.Click

        CheckBox28.Enabled = True
    End Sub

    Private Sub Button29_Click_1(sender As Object, e As EventArgs) Handles Button29.Click

        CheckBox29.Enabled = True
    End Sub


    Private Sub GroupBox2_Enter(sender As Object, e As EventArgs)

    End Sub

    Private Sub CheckBox1_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox2.CheckedChanged

        TextBox1.Enabled = True
        TextBox1.Text = ""
        TextBox1.Focus()

    End Sub

    Private Sub CheckBox2_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox2.CheckedChanged

        TextBox2.Enabled = True
        TextBox2.Text = ""
        TextBox2.Focus()

    End Sub

    Private Sub CheckBox3_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox3.CheckedChanged

        TextBox3.Enabled = True
        TextBox3.Text = ""
        TextBox3.Focus()

    End Sub

    Private Sub CheckBox4_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox4.CheckedChanged

        TextBox4.Enabled = True
        TextBox4.Text = ""
        TextBox4.Focus()

    End Sub

    Private Sub CheckBox5_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox5.CheckedChanged

        TextBox5.Enabled = True
        TextBox5.Text = ""
        TextBox5.Focus()

    End Sub

    Private Sub CheckBox6_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox6.CheckedChanged

        TextBox6.Enabled = True
        TextBox6.Text = ""
        TextBox6.Focus()

    End Sub

    Private Sub CheckBox7_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox7.CheckedChanged


        TextBox7.Enabled = True
        TextBox7.Text = ""
        TextBox7.Focus()

    End Sub

    Private Sub CheckBox8_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox8.CheckedChanged

        TextBox8.Enabled = True
        TextBox8.Text = ""
        TextBox8.Focus()

    End Sub

    Private Sub CheckBox9_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox9.CheckedChanged

        TextBox9.Enabled = True
        TextBox9.Text = ""
        TextBox9.Focus()

    End Sub

    Private Sub CheckBox10_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox10.CheckedChanged

        TextBox10.Enabled = True
        TextBox10.Text = ""
        TextBox10.Focus()

    End Sub

    Private Sub CheckBox11_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox11.CheckedChanged

        TextBox11.Enabled = True
        TextBox11.Text = ""
        TextBox11.Focus()

    End Sub

    Private Sub CheckBox12_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox12.CheckedChanged

        TextBox12.Enabled = True
        TextBox12.Text = ""
        TextBox12.Focus()

    End Sub

    Private Sub CheckBox13_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox13.CheckedChanged

        TextBox13.Enabled = True
        TextBox13.Text = ""
        TextBox13.Focus()

    End Sub

    Private Sub CheckBox14_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox14.CheckedChanged

        TextBox14.Enabled = True
        TextBox14.Text = ""
        TextBox14.Focus()

    End Sub

    Private Sub CheckBox15_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox15.CheckedChanged

        TextBox15.Enabled = True
        TextBox15.Text = ""
        TextBox15.Focus()

    End Sub

    Private Sub CheckBox16_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox16.CheckedChanged

        TextBox16.Enabled = True
        TextBox16.Text = ""
        TextBox16.Focus()

    End Sub



    Private Sub CheckBox29_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox29.CheckedChanged

        TextBox29.Enabled = True
        TextBox29.Text = ""
        TextBox29.Focus()

    End Sub

    Private Sub CheckBox28_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox28.CheckedChanged

        TextBox28.Enabled = True
        TextBox28.Text = ""
        TextBox28.Focus()

    End Sub

    Private Sub CheckBox27_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox27.CheckedChanged

        TextBox27.Enabled = True
        TextBox27.Text = ""
        TextBox27.Focus()

    End Sub

    Private Sub CheckBox26_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox26.CheckedChanged

        TextBox26.Enabled = True
        TextBox26.Text = ""
        TextBox26.Focus()

    End Sub

    Private Sub CheckBox25_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox25.CheckedChanged

        TextBox25.Enabled = True
        TextBox25.Text = ""
        TextBox25.Focus()

    End Sub

    Private Sub CheckBox24_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox24.CheckedChanged

        TextBox24.Enabled = True
        TextBox24.Text = ""
        TextBox24.Focus()

    End Sub

    Private Sub CheckBox23_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox23.CheckedChanged

        TextBox23.Enabled = True
        TextBox23.Text = ""
        TextBox23.Focus()

    End Sub

    Private Sub CheckBox22_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox22.CheckedChanged

        TextBox22.Enabled = True
        TextBox22.Text = ""
        TextBox22.Focus()

    End Sub

    Private Sub CheckBox21_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox21.CheckedChanged

        TextBox21.Enabled = True
        TextBox21.Text = ""
        TextBox21.Focus()

    End Sub

    Private Sub CheckBox20_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox20.CheckedChanged

        TextBox20.Enabled = True
        TextBox20.Text = ""
        TextBox20.Focus()

    End Sub

    Private Sub CheckBox19_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox19.CheckedChanged

        TextBox19.Enabled = True
        TextBox19.Text = ""
        TextBox19.Focus()

    End Sub

    Private Sub CheckBox18_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox18.CheckedChanged

        TextBox18.Enabled = True
        TextBox18.Text = ""
        TextBox18.Focus()

    End Sub

    Private Sub CheckBox17_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox17.CheckedChanged

        TextBox17.Enabled = True
        TextBox17.Text = ""
        TextBox17.Focus()

    End Sub

    Private Sub Button24_Click_1(sender As Object, e As EventArgs) Handles Button24.Click
        CheckBox24.Enabled = True
    End Sub

    Private Sub Button33_Click_1(sender As Object, e As EventArgs) Handles Button33.Click
        Dim Iexit As DialogResult

        Iexit = MessageBox.Show("Do you really want to quit this program", "Exit - Program", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning)

        If Iexit = Windows.Forms.DialogResult.Yes Then
            Application.Exit()
        End If

    End Sub

    Private Sub Button34_Click_1(sender As Object, e As EventArgs) Handles Button34.Click

        For Each t In {TextBox1, TextBox10, TextBox11, TextBox12, TextBox13, TextBox14, TextBox15, TextBox16, TextBox6, TextBox5, TextBox4, TextBox3, TextBox29, TextBox28,
      TextBox27, TextBox26, TextBox25, TextBox24, TextBox23, TextBox22,
      TextBox21, TextBox20, TextBox2, TextBox19, TextBox18, TextBox7, TextBox8, TextBox9,
      TextBox17}



            t.Clear()
            t.Refresh()
        Next

        Label1.Text = ""
        Label2.Text = ""
        Label3.Text = ""
        RichTextBox1.Text = ""

        For Each R In {CheckBox1, CheckBox10, CheckBox11, CheckBox12, CheckBox13, CheckBox13, CheckBox14, CheckBox15, CheckBox16, CheckBox17, CheckBox18, CheckBox19, CheckBox2, CheckBox20, CheckBox21, CheckBox22, CheckBox23, CheckBox24, CheckBox25, CheckBox26, CheckBox27, CheckBox28, CheckBox29, CheckBox3, CheckBox9, CheckBox8, CheckBox7, CheckBox6, CheckBox5, CheckBox4}

            R.Checked = False
            R.Refresh()
        Next


        For Each L In {Label1, Label2, Label3}

            L.Refresh()
        Next

    End Sub


    Private Sub OpenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenToolStripMenuItem.Click
        Dim open As New OpenFileDialog()
        open.Filter = "Rich Text Document (* .doc) |*.doc|All files (*.*)|*.*"
        open.CheckPathExists = True
        If open.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
            Try
                RichTextBox1.LoadFile(OpenFileDialog1.FileName, RichTextBoxStreamType.RichText)

            Catch ex As Exception
                'Do nothing
            End Try




        End If

    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click

        Me.Refresh()

    End Sub



    Private Sub SaveToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveToolStripMenuItem.Click

        Dim Save As New SaveFileDialog()
        Save.Filter = "Rich Text Document (* .doc) |*.doc|All files (*.*)|*.*"
        Save.CheckPathExists = True
        If Save.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
            Try
                RichTextBox1.SaveFile(SaveFileDialog1.FileName, RichTextBoxStreamType.RichText)


                MessageBox.Show("Ok  I will do so")


SaveErr:
                Exit Sub

            Catch ex As Exception
                'Do nothing

            End Try





        End If

    End Sub

    Private Sub SaveAsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveAsToolStripMenuItem.Click


        Dim Saveas As New SaveFileDialog()
        Saveas.Filter = "Rich Text Document (* .doc) |*.doc|All files (*.*)|*.*"
        Saveas.CheckPathExists = True
        If Saveas.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
            Try
                RichTextBox1.SaveFile(SaveFileDialog1.FileName, RichTextBoxStreamType.RichText)

            Catch ex As Exception
                'Do nothing
            End Try
        End If
    End Sub

    Private Sub PrintPreviewToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PrintPreviewToolStripMenuItem.Click


        PrintPreviewDialog1.Document = PrintDocument1
        PrintPreviewDialog1.ShowDialog()
    End Sub

    Private Sub PrintToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PrintToolStripMenuItem.Click
        PrintDialog1.Document = PrintDocument1
        PrintDialog1.PrinterSettings = PrintDocument1.PrinterSettings
        PrintDialog1.AllowSomePages = True
        If PrintDialog1.ShowDialog = DialogResult.OK Then
            PrintDocument1.PrinterSettings = PrintDialog1.PrinterSettings
            PrintDocument1.Print()
        End If
        Try
            PrintDialog1.ShowDialog()
            If PrintDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
                PrintDocument1.Print()
            End If
        Catch ex As Exception

        End Try


    End Sub

    Private Sub PrintDocument1_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Static currentChar As Integer
        Static currentLine As Integer
        Dim textfont As Font = RichTextBox1.Font
        Dim h, w As Integer
        Dim left, top As Integer
        With PrintDocument1.DefaultPageSettings
            h = .PaperSize.Height - .Margins.Top - .Margins.Bottom
            w = .PaperSize.Width - .Margins.Left - .Margins.Right
            left = PrintDocument1.DefaultPageSettings.Margins.Left
            top = PrintDocument1.DefaultPageSettings.Margins.Top
        End With
        e.Graphics.DrawRectangle(Pens.Blue, New Rectangle(left, top, w, h))
        If PrintDocument1.DefaultPageSettings.Landscape Then
            Dim a As Integer
            a = h
            h = w
            w = a
        End If
        Dim lines As Integer = CInt(Math.Round(h / textfont.Height))
        Dim b As New Rectangle(left, top, w, h)
        Dim format As StringFormat
        If Not RichTextBox1.WordWrap Then
            format = New StringFormat(StringFormatFlags.NoWrap)
            format.Trimming = StringTrimming.EllipsisWord
            Dim i As Integer
            For i = currentLine To Math.Min(currentLine + lines, RichTextBox1.Lines.Length - 1)
                e.Graphics.DrawString(RichTextBox1.Lines(i), textfont, Brushes.Black, New RectangleF(left, top + textfont.Height * (i - currentLine), w, textfont.Height), format)
            Next
            currentLine += lines
            If currentLine >= RichTextBox1.Lines.Length Then
                e.HasMorePages = False
                currentLine = 0
            Else
                e.HasMorePages = True
            End If
            Exit Sub
        End If
        format = New StringFormat(StringFormatFlags.LineLimit)
        Dim line, chars As Integer
        e.Graphics.MeasureString(Mid(RichTextBox1.Text, currentChar + 1), textfont, New SizeF(w, h), format, chars, line)
        If currentChar + chars < RichTextBox1.Text.Length Then
            If RichTextBox1.Text.Substring(currentChar + chars, 1) <> " " And RichTextBox1.Text.Substring(currentChar + chars, 1) <> vbLf Then
                While chars > 0
                    RichTextBox1.Text.Substring(currentChar + chars, 1)
                    RichTextBox1.Text.Substring(currentChar + chars, 1)
                    chars -= 1
                End While
                chars += 1
            End If
        End If
        e.Graphics.DrawString(RichTextBox1.Text.Substring(currentChar, chars), textfont, Brushes.Black, b, format)
        currentChar = currentChar + chars
        If currentChar < RichTextBox1.Text.Length Then
            e.HasMorePages = True
        Else
            e.HasMorePages = False
            currentChar = 0
        End If
    End Sub


    Private Sub NewToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NewToolStripMenuItem.Click






    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick






    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick




    End Sub

    Private Sub Button31_Click(sender As Object, e As EventArgs) Handles Button31.Click
        Me.Visible = False
        Main_Administration_screen.Visible = True
    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click
        Label4.Visible = False
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        Label3.Visible = False
    End Sub

    Private Sub GroupBox3_Enter(sender As Object, e As EventArgs) Handles GroupBox3.Enter

    End Sub


    Private Sub Button40_Click(sender As Object, e As EventArgs)
        Email.Visible = True
    End Sub

    Private Sub InternetToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InternetToolStripMenuItem.Click

    End Sub

    Private Sub InternetToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles InternetToolStripMenuItem1.Click

    End Sub

    Private Sub EmailToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EmailToolStripMenuItem.Click

    End Sub

    Private Sub RepoortToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RepoortToolStripMenuItem.Click

    End Sub

    Private Sub SearchOnlineToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SearchOnlineToolStripMenuItem.Click
        Me.Visible = False

        Me.Refresh()
        Email.Visible = True
    End Sub

    Private Sub InternetBrowserToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InternetBrowserToolStripMenuItem.Click
        Me.Visible = False
        InternetBrowser.Visible = True
    End Sub

    Private Sub HomeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HomeToolStripMenuItem.Click
        Me.Visible = False
        Home.visible = True

    End Sub

    Private Sub ServiceToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ServiceToolStripMenuItem.Click

    End Sub
End Class
