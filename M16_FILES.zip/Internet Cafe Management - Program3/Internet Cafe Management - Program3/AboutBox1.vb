﻿Public NotInheritable Class AboutBox1

    Private Sub AboutBox1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Set the title of the form.
        Dim ApplicationTitle As String
        If My.Application.Info.Title <> "" Then
            ApplicationTitle = My.Application.Info.Title
        Else
            ApplicationTitle = System.IO.Path.GetFileNameWithoutExtension(My.Application.Info.AssemblyName)
        End If
        Me.Text = String.Format("About {0}", ApplicationTitle)
        ' Initialize all of the text displayed on the About Box.
        ' TODO: Customize the application's assembly information in the "Application" pane of the project 
        '    properties dialog (under the "Project" menu).
        Me.LabelProductName.Text = My.Application.Info.ProductName
        Me.LabelVersion.Text = String.Format("Version {0}", My.Application.Info.Version.ToString)
        Me.LabelCopyright.Text = My.Application.Info.Copyright
        Me.LabelCompanyName.Text = My.Application.Info.CompanyName
        Me.TextBoxDescription.Text = My.Application.Info.Description
    End Sub

    Private Sub TextBoxDescription_TextChanged(sender As Object, e As EventArgs) Handles TextBoxDescription.TextChanged
        TextBoxDescription.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        TextBoxDescription.Text = "Description : M16 Interior Version 1.0.0.0 Is created And manufactured at Masikane IT 
                                       Solutions(PTY) LTD Company. M16 Interior Is created For the Internet Cafes As these 
                                       Software serves as an point of sale to assist the cashier Or administrator ofwhich
                                       M16 Interior Is your notebook, whereby M16 Interior Is the New evolution to the whole
                                       Internet Cafes around the world. M16 Interior founded by Prof Mosa Moabi VXiii at 
                                       Masikane IT Solutions (PTY) LTD Company which Is the company which supplied material &
                                       supplied with alot of machinery to get this software completed till date under its base.
                                            M16 INTERIOR - Point OF SALE RESERVED AT MASIKANE IT SOLUTIONS (PTY) LTD COMPANY"
    End Sub

    Private Sub OKButton_Click(sender As Object, e As EventArgs) Handles OKButton.Click
        Me.Close()
        Application.Exit()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Visible = False
        Main_Administration_screen.Visible = True
    End Sub

    Private Sub LabelVersion_Click(sender As Object, e As EventArgs) Handles LabelVersion.Click

    End Sub
End Class
